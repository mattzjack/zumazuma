# zumazuma

This is a term project for 15-112.

To run the program, first make sure to have Python 3 and Pygame installed. To
install Pygame:

    pip3 install pygame

Also, change the host IP to your IP if you want different computers to connect;
leave it as a blank string to test it out on one computer.

## Testing

First run the server with

    python3 /path/to/server.py

Then, run max of two instances of main

    python3 /path/to/main.py

Disconnecting will result in broken pipe error for now.
